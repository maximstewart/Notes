#include "interface/font.h"

extern LG_Font * LG_Fonts[];

#define LG_FONT_COUNT 1
