#include "interface/renderer.h"

extern LG_Renderer * LG_Renderers[];

#define LG_RENDERER_COUNT 2
