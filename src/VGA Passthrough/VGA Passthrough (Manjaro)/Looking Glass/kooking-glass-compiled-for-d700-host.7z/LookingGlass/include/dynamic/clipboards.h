#include "interface/clipboard.h"

extern LG_Clipboard * LG_Clipboards[];

#define LG_CLIPBOARD_COUNT 1
