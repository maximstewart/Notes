extern const char b_shader_splash_logo_vert[];
extern const char b_shader_splash_logo_vert_end[];
#define b_shader_splash_logo_vert_size (b_shader_splash_logo_vert_end - b_shader_splash_logo_vert)
