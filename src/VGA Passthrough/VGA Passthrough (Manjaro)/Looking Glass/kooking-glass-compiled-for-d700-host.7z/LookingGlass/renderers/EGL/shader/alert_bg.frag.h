extern const char b_shader_alert_bg_frag[];
extern const char b_shader_alert_bg_frag_end[];
#define b_shader_alert_bg_frag_size (b_shader_alert_bg_frag_end - b_shader_alert_bg_frag)
