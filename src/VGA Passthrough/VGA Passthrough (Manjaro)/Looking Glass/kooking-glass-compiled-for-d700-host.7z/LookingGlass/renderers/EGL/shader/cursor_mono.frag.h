extern const char b_shader_cursor_mono_frag[];
extern const char b_shader_cursor_mono_frag_end[];
#define b_shader_cursor_mono_frag_size (b_shader_cursor_mono_frag_end - b_shader_cursor_mono_frag)
