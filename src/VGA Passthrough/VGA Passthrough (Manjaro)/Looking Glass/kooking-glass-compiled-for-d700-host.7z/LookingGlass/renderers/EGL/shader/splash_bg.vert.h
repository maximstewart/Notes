extern const char b_shader_splash_bg_vert[];
extern const char b_shader_splash_bg_vert_end[];
#define b_shader_splash_bg_vert_size (b_shader_splash_bg_vert_end - b_shader_splash_bg_vert)
