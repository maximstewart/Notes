#include "interface/renderer.h"

#include <stddef.h>

extern LG_Renderer LGR_EGL;
extern LG_Renderer LGR_OpenGL;

const LG_Renderer * LG_Renderers[] =
{
  &LGR_EGL,
  &LGR_OpenGL,
  NULL
};