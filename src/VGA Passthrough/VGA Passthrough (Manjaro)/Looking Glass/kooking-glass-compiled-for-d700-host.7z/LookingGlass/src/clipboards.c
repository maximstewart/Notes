#include "interface/clipboard.h"

#include <stddef.h>

extern LG_Clipboard LGC_X11;

const LG_Clipboard * LG_Clipboards[] =
{
  &LGC_X11,
  NULL
};

