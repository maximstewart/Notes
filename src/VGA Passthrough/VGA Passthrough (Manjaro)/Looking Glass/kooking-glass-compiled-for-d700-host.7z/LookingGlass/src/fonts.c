#include "interface/font.h"

#include <stddef.h>

extern LG_Font LGF_SDL;

const LG_Font * LG_Fonts[] =
{
  &LGF_SDL,
  NULL
};

